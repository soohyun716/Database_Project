create definer = root@localhost view db2024_lectureview as
select `db2024team05`.`db2024_space_info`.`Room_Name`   AS `Room_Name`,
       `db2024team05`.`db2024_space_info`.`Location`    AS `Location`,
       `db2024team05`.`db2024_lecture`.`Lecture_Num`    AS `Lecture_Num`,
       `db2024team05`.`db2024_lecture`.`Class_Num`      AS `Class_Num`,
       `db2024team05`.`db2024_lecture`.`Lecture_Name`   AS `Lecture_Name`,
       `db2024team05`.`db2024_lecture`.`Professor_Name` AS `Professor_Name`,
       `db2024team05`.`db2024_lecture`.`Professor_Num`  AS `Professor_Num`,
       `db2024team05`.`db2024_lecture`.`Room_Number`    AS `Room_Number`,
       `db2024team05`.`db2024_lecture`.`Lecture_Time1`  AS `Lecture_Time1`,
       `db2024team05`.`db2024_lecture`.`Lecture_Time2`  AS `Lecture_Time2`
from `db2024team05`.`db2024_lecture`
         join `db2024team05`.`db2024_space_info`
where (`db2024team05`.`db2024_space_info`.`Room_Number` = `db2024team05`.`db2024_lecture`.`Room_Number`);

