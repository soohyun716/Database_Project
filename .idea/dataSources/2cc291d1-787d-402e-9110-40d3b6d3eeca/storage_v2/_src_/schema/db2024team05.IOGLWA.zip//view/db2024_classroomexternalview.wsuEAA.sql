create definer = root@localhost view db2024_classroomexternalview as
select `db2024team05`.`db2024_space_info`.`Room_Name`                  AS `Room_Name`,
       `db2024team05`.`db2024_space_info`.`Location`                   AS `Location`,
       `db2024team05`.`db2024_classroom_external`.`Room_Number`        AS `Room_Number`,
       `db2024team05`.`db2024_classroom_external`.`Eat_Available`      AS `Eat_Available`,
       `db2024team05`.`db2024_classroom_external`.`Noise_Level`        AS `Noise_Level`,
       `db2024team05`.`db2024_classroom_external`.`Reservation_Needed` AS `Reservation_Needed`,
       `db2024team05`.`db2024_classroom_external`.`Seat_Count`         AS `Seat_Count`,
       `db2024team05`.`db2024_classroom_external`.`Outlet_Count`       AS `Outlet_Count`
from `db2024team05`.`db2024_classroom_external`
         join `db2024team05`.`db2024_space_info`
where (`db2024team05`.`db2024_space_info`.`Room_Number` = `db2024team05`.`db2024_classroom_external`.`Room_Number`);

