create definer = root@localhost view db2024_classroomview as
select `db2024team05`.`db2024_space_info`.`Room_Name`          AS `Room_Name`,
       `db2024team05`.`db2024_space_info`.`Location`           AS `Location`,
       `db2024team05`.`db2024_classroom`.`Room_Number`         AS `Room_Number`,
       `db2024team05`.`db2024_classroom`.`Practicable`         AS `Practicable`,
       `db2024team05`.`db2024_classroom`.`Seat_Count`          AS `Seat_Count`,
       `db2024team05`.`db2024_classroom`.`Projector`           AS `Projector`,
       `db2024team05`.`db2024_classroom`.`OutletCount`         AS `OutletCount`,
       `db2024team05`.`db2024_classroom`.`ReservationRequired` AS `ReservationRequired`,
       `db2024team05`.`db2024_classroom`.`RecordingAvailable`  AS `RecordingAvailable`,
       `db2024team05`.`db2024_classroom`.`CameraType`          AS `CameraType`
from `db2024team05`.`db2024_classroom`
         join `db2024team05`.`db2024_space_info`
where (`db2024team05`.`db2024_space_info`.`Room_Number` = `db2024team05`.`db2024_classroom`.`Room_Number`);

